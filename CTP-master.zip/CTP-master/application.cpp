#include <iostream>
#include "Tests.h"
#include "UI.h"

int main() {

    UI ui=UI();
    ui.run();
    std::cout << "La revedere!" <<endl ;
	system("pause");

    return 0;
}